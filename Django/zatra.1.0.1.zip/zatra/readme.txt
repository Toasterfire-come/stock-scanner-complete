== Zatra ==
Contributors: Dezign Digital
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Changelog ==
= 1.0.1 =
* Remove accessibility-ready tag

= 1.0.0 =
* Initial release


== Copyright ==

Zatra WordPress Theme, (C) 2024 Dezign Digital
Zatra is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details. 


== Credits ==

Font Awesome https://fontawesome.com Font Awesome Free 6.6.0 Copyright 2024 Fonticons, Inc. License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

Poppins font
License: SIL Open Font License, 1.1, https://opensource.org/licenses/OFL-1.1
Soure: https://fonts.google.com/specimen/Poppins

Nunito font
License: SIL Open Font License, 1.1, https://opensource.org/licenses/OFL-1.1
Source: https://fonts.google.com/specimen/Nunito

= Images License =
https://stocksnap.io/photo/abstract-wavy-UOTSJVB9HM [https://stocksnap.io/license]
https://stocksnap.io/photo/business-people-VIEC4IZZRI [https://stocksnap.io/license]
https://pxhere.com/en/photo/1437653 [https://pxhere.com/en/license]
