from django.contrib import admin
from .models import EmailSubscription

admin.site.register(EmailSubscription)
