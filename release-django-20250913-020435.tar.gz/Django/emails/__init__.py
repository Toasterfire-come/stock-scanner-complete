try:
    from . import tasks
except ImportError:
    pass
