from django.contrib import admin
from .models import NewsArticle

admin.site.register(NewsArticle)
