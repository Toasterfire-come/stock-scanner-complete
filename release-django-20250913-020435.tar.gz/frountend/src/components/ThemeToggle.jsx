import React from "react";
// Dark mode removed

const ThemeToggle = () => null;

export default ThemeToggle;

